package com.mycompany.tpsms.views;

import com.mycompany.tpsms.controllers.StockMovementController;
import com.mycompany.tpsms.database.models.StockMovement;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import java.util.Date;

public class InventoryPanel extends JPanel {
    private JTable stockTable;
    private JButton btnReceive, btnIssue;
    private DefaultTableModel tableModel;
    private StockMovementController stockMovementController;

    public InventoryPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(245, 245, 245));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Initialize StockMovementController
        stockMovementController = new StockMovementController();

        // Header Panel
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(30, 136, 229), 
                    getWidth(), 0, new Color(33, 150, 243));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setPreferredSize(new Dimension(0, 80));
        
        JLabel titleLabel = new JLabel("Inventory Management");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        // Stock Movement Table
        String[] columnNames = {"Date", "Material", "Type", "Quantity", "Location", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        stockTable = new JTable(tableModel);
        stockTable.setShowGrid(false);
        stockTable.setIntercellSpacing(new Dimension(0, 0));
        stockTable.setSelectionBackground(new Color(33, 150, 243, 100));
        stockTable.setSelectionForeground(Color.BLACK);
        stockTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        stockTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        stockTable.getTableHeader().setBackground(new Color(33, 150, 243));
        stockTable.getTableHeader().setForeground(Color.WHITE);
        stockTable.setRowHeight(30);

        // Quick Actions Panel
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actionPanel.setBackground(Color.WHITE);
        
        btnReceive = createStockButton("📥 Receive Stock", new Color(76, 175, 80));
        btnIssue = createStockButton("📤 Issue Stock", new Color(244, 67, 54));
        
        actionPanel.add(btnReceive);
        actionPanel.add(btnIssue);

        // Add action listeners
        btnReceive.addActionListener(e -> showStockMovementDialog("Receive"));
        btnIssue.addActionListener(e -> showStockMovementDialog("Issue"));

        // Layout
        tablePanel.add(new JScrollPane(stockTable), BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        add(actionPanel, BorderLayout.SOUTH);

        // Load stock movements into the table
        loadStockMovements();
    }

    private JButton createStockButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return btn;
    }

    // Method to load stock movements into the table
    private void loadStockMovements() {
        try {
            List<StockMovement> movements = stockMovementController.listStockMovements();
            updateStockTable(movements);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load stock movements: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to update the stock movements table
    public void updateStockTable(List<StockMovement> movements) {
        tableModel.setRowCount(0); // Clear existing data
        for (StockMovement movement : movements) {
            Object[] row = {
                movement.getMovementDate(),
                movement.getMaterialId(),
                movement.getMovementType(),
                movement.getQuantity(),
                movement.getProjectId(),
//                movement.getStatus
            };
            tableModel.addRow(row);
        }
    }

    // Method to show the stock movement dialog
    private void showStockMovementDialog(String movementType) {
        JTextField materialIdField = new JTextField();
        JTextField quantityField = new JTextField();
        JTextField movementDateField = new JTextField();
        JTextField projectIdField = new JTextField();

        Object[] fields = {
            "Material ID:", materialIdField,
            "Quantity:", quantityField,
            "Movement Date (YYYY-MM-DD):", movementDateField,
            "Project ID:", projectIdField
        };

        int option = JOptionPane.showConfirmDialog(
            this,
            fields,
            movementType + " Stock",
            JOptionPane.OK_CANCEL_OPTION
        );

        if (option == JOptionPane.OK_OPTION) {
            try {
                int materialId = Integer.parseInt(materialIdField.getText());
                double quantity = Double.parseDouble(quantityField.getText());
                Date movementDate = java.sql.Date.valueOf(movementDateField.getText());
                int projectId = Integer.parseInt(projectIdField.getText());

                stockMovementController.addStockMovement(materialId, quantity, movementType, movementDate, projectId);
                loadStockMovements(); // Refresh the table
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Invalid input: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}

