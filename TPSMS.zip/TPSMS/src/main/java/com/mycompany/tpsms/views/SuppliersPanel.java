/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tpsms.views;

import com.mycompany.tpsms.controllers.SupplierController;
import com.mycompany.tpsms.database.models.Supplier;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author blackheart
 */
public class SuppliersPanel extends JPanel {
    private JTable suppliersTable;
    private JButton btnNewSupplier, btnAddSupplier, btnUpdateSupplier, btnDeleteSupplier;
    private DefaultTableModel tableModel;
    private SupplierController supplierController;

    public SuppliersPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(245, 245, 245));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Initialize SupplierController
        supplierController = new SupplierController();

        // Header Panel
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(30, 136, 229), 
                    getWidth(), 0, new Color(33, 150, 243));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setPreferredSize(new Dimension(0, 80));
        
        JLabel titleLabel = new JLabel("Supplier Management");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Search Panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        searchPanel.setOpaque(false);
        
        JTextField searchField = new JTextField(25);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        searchField.putClientProperty("JTextField.placeholderText", "Search suppliers...");
        
        JButton searchButton = new JButton("Search");
        searchButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        searchButton.setBackground(new Color(76, 175, 80));
        searchButton.setForeground(Color.WHITE);
        searchButton.setFocusPainted(false);
        
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        headerPanel.add(searchPanel, BorderLayout.EAST);

        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        // Suppliers Table
        String[] columnNames = {"ID", "Name", "Contact", "Phone", "Email", "Address", "Rating"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        suppliersTable = new JTable(tableModel);
        suppliersTable.setShowGrid(false);
        suppliersTable.setIntercellSpacing(new Dimension(0, 0));
        suppliersTable.setSelectionBackground(new Color(33, 150, 243, 100));
        suppliersTable.setSelectionForeground(Color.BLACK);
        suppliersTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        suppliersTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        suppliersTable.getTableHeader().setBackground(new Color(33, 150, 243));
        suppliersTable.getTableHeader().setForeground(Color.WHITE);
        suppliersTable.setRowHeight(30);

        // Control Buttons Panel
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        controlPanel.setBackground(Color.WHITE);
        
        btnAddSupplier = createControlButton("➕ Add Supplier", new Color(0, 153, 51));
        btnUpdateSupplier = createControlButton("✏️ Update Supplier", new Color(0, 102, 204));
        btnDeleteSupplier = createControlButton("🗑️ Delete Supplier", new Color(204, 0, 0));
        
        controlPanel.add(btnAddSupplier);
        controlPanel.add(btnUpdateSupplier);
        controlPanel.add(btnDeleteSupplier);

        // Add action listeners
        btnAddSupplier.addActionListener(e -> showSupplierDialog("Add"));
        btnUpdateSupplier.addActionListener(e -> showSupplierDialog("Update"));
        btnDeleteSupplier.addActionListener(e -> deleteSelectedSupplier());

        // Layout
        tablePanel.add(new JScrollPane(suppliersTable), BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);

        // Load suppliers into the table
        loadSuppliers();
    }

    private JButton createControlButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return btn;
    }

    // Method to load suppliers into the table
    private void loadSuppliers() {
        try {
            List<Supplier> suppliers = supplierController.listSuppliers();
            updateSupplierTable(suppliers);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load suppliers: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to update the suppliers table
    public void updateSupplierTable(List<Supplier> suppliers) {
        tableModel.setRowCount(0); // Clear existing data
        for (Supplier supplier : suppliers) {
            Object[] row = {
                supplier.getId(),
                supplier.getName(),
                supplier.getContactPerson(),
                supplier.getPhone(),
                supplier.getEmail(),
                supplier.getAddress(),
//                supplier.getRating()
            };
            tableModel.addRow(row);
        }
    }

    // Method to show the supplier dialog
    private void showSupplierDialog(String action) {
        JTextField nameField = new JTextField();
        JTextField contactPersonField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField addressField = new JTextField();

        Object[] fields = {
            "Name:", nameField,
            "Contact Person:", contactPersonField,
            "Phone:", phoneField,
            "Email:", emailField,
            "Address:", addressField
        };

        int option = JOptionPane.showConfirmDialog(
            this,
            fields,
            action + " Supplier",
            JOptionPane.OK_CANCEL_OPTION
        );

        if (option == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                String contactPerson = contactPersonField.getText();
                String phone = phoneField.getText();
                String email = emailField.getText();
                String address = addressField.getText();

                if (action.equals("Add")) {
                    supplierController.addSupplier(name, contactPerson, phone, email, address);
                } else if (action.equals("Update")) {
                    int selectedRow = suppliersTable.getSelectedRow();
                    if (selectedRow == -1) {
                        JOptionPane.showMessageDialog(this, "Please select a supplier to update.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    int id = (int) tableModel.getValueAt(selectedRow, 0);
                    supplierController.updateSupplier(id, name, contactPerson, phone, email, address);
                }

                loadSuppliers(); // Refresh the table
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Invalid input: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Method to delete the selected supplier
    private void deleteSelectedSupplier() {
        int selectedRow = suppliersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a supplier to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int id = (int) tableModel.getValueAt(selectedRow, 0); // Get the ID from the first column
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete this supplier?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                supplierController.deleteSupplier(id);
                loadSuppliers(); // Refresh the table
                JOptionPane.showMessageDialog(this, "Supplier deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Failed to delete supplier: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
