/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tpsms.views;

import com.mycompany.tpsms.controllers.PurchaseOrderController;
import com.mycompany.tpsms.database.models.PurchaseOrder;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

/**
 *
 * @author blackheart
 */
public class ComponentsPanel extends JPanel {
    private JTable ordersTable;
    private JButton btnNewOrder, btnAddOrder, btnUpdateOrder, btnDeleteOrder;
    private DefaultTableModel tableModel;
    private PurchaseOrderController purchaseOrderController;

    public ComponentsPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(245, 245, 245));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Initialize PurchaseOrderController
        purchaseOrderController = new PurchaseOrderController();

        // Header Panel
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(30, 136, 229), 
                    getWidth(), 0, new Color(33, 150, 243));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setPreferredSize(new Dimension(0, 80));
        
        JLabel titleLabel = new JLabel("Component Management");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        // Orders Table
        String[] columnNames = {"ID", "Component", "Supplier", "Quantity", "Order Date", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        ordersTable = new JTable(tableModel);
        ordersTable.setShowGrid(false);
        ordersTable.setIntercellSpacing(new Dimension(0, 0));
        ordersTable.setSelectionBackground(new Color(33, 150, 243, 100));
        ordersTable.setSelectionForeground(Color.BLACK);
        ordersTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        ordersTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        ordersTable.getTableHeader().setBackground(new Color(33, 150, 243));
        ordersTable.getTableHeader().setForeground(Color.WHITE);
        ordersTable.setRowHeight(30);

        // Action Buttons Panel
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actionPanel.setBackground(Color.WHITE);
        
        btnNewOrder = createActionButton("📝 New Order", new Color(0, 153, 51));
        btnAddOrder = createActionButton("➕ Add Component", new Color(76, 175, 80));
        btnUpdateOrder = createActionButton("✏️ Update Order", new Color(0, 102, 204));
        btnDeleteOrder = createActionButton("🗑️ Delete Order", new Color(204, 0, 0));
        
        actionPanel.add(btnNewOrder);
        actionPanel.add(btnAddOrder);
        actionPanel.add(btnUpdateOrder);
        actionPanel.add(btnDeleteOrder);

        // Add action listeners
        btnNewOrder.addActionListener(e -> showOrderDialog("Add"));
        btnAddOrder.addActionListener(e -> showOrderDialog("Add"));
        btnUpdateOrder.addActionListener(e -> showOrderDialog("Update"));
        btnDeleteOrder.addActionListener(e -> deleteSelectedOrder());

        // Layout
        tablePanel.add(new JScrollPane(ordersTable), BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        add(actionPanel, BorderLayout.SOUTH);

        // Load purchase orders into the table
        loadPurchaseOrders();
    }

    private JButton createActionButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return btn;
    }

    // Method to load purchase orders into the table
    private void loadPurchaseOrders() {
        try {
            List<PurchaseOrder> orders = purchaseOrderController.listPurchaseOrders();
            updateOrderTable(orders);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load purchase orders: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to update the purchase orders table
    public void updateOrderTable(List<PurchaseOrder> orders) {
        tableModel.setRowCount(0); // Clear existing data
        for (PurchaseOrder order : orders) {
            Object[] row = {
                order.getId(),
                order.getSupplierId(),
                
                order.getOrderDate(),
                order.getTotalAmount(),
                order.getDeliveryDate(),
                order.getStatus()
            };
            tableModel.addRow(row);
        }
    }

    // Method to show the order dialog
    private void showOrderDialog(String action) {
        JTextField supplierIdField = new JTextField();
        JTextField orderDateField = new JTextField();
        JTextField deliveryDateField = new JTextField();
        JTextField statusField = new JTextField();
        JTextField totalAmountField = new JTextField();

        Object[] fields = {
            "Supplier ID:", supplierIdField,
            "Order Date (YYYY-MM-DD):", orderDateField,
            "Delivery Date (YYYY-MM-DD):", deliveryDateField,
            "Status:", statusField,
            "Total Amount:", totalAmountField
        };

        int option = JOptionPane.showConfirmDialog(
            this,
            fields,
            action + " Purchase Order",
            JOptionPane.OK_CANCEL_OPTION
        );

        if (option == JOptionPane.OK_OPTION) {
            try {
                int supplierId = Integer.parseInt(supplierIdField.getText());
                Date orderDate = java.sql.Date.valueOf(orderDateField.getText());
                Date deliveryDate = java.sql.Date.valueOf(deliveryDateField.getText());
                String status = statusField.getText();
                double totalAmount = Double.parseDouble(totalAmountField.getText());

                if (action.equals("Add")) {
                    purchaseOrderController.addPurchaseOrder(supplierId, orderDate, deliveryDate, status, totalAmount);
                } else if (action.equals("Update")) {
                    int selectedRow = ordersTable.getSelectedRow();
                    if (selectedRow == -1) {
                        JOptionPane.showMessageDialog(this, "Please select an order to update.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    int id = (int) tableModel.getValueAt(selectedRow, 0);
                    purchaseOrderController.updatePurchaseOrder(id, supplierId, orderDate, status, totalAmount);
                }

                loadPurchaseOrders(); // Refresh the table
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Invalid input: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Method to delete the selected order
    private void deleteSelectedOrder() {
        int selectedRow = ordersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an order to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int id = (int) tableModel.getValueAt(selectedRow, 0); // Get the ID from the first column
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete this order?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                purchaseOrderController.deletePurchaseOrder(id);
                loadPurchaseOrders(); // Refresh the table
                JOptionPane.showMessageDialog(this, "Order deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Failed to delete order: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
