package com.mycompany.tpsms.services;

import com.mycompany.tpsms.database.daos.StockMovementDAO;
import com.mycompany.tpsms.database.models.StockMovement;
import java.sql.SQLException;
import java.util.List;

public class StockMovementService {
    private final StockMovementDAO stockMovementDAO;

    public StockMovementService() {
        this.stockMovementDAO = new StockMovementDAO();
    }

    public void addStockMovement(StockMovement movement) throws SQLException {
        stockMovementDAO.create(movement);
    }

    public StockMovement getStockMovementById(int id) throws SQLException {
        return stockMovementDAO.read(id);
    }

    public List<StockMovement> getAllStockMovements() throws SQLException {
        return stockMovementDAO.getAll();
    }

    public void updateStockMovement(StockMovement movement) throws SQLException {
        stockMovementDAO.update(movement);
    }

    public void deleteStockMovement(int id) throws SQLException {
        stockMovementDAO.delete(id);
    }
} 