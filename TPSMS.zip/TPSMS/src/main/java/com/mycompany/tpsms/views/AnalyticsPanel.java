/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tpsms.views;

import com.mycompany.tpsms.controllers.ProjectController;
import com.mycompany.tpsms.controllers.StockMovementController;
import com.mycompany.tpsms.controllers.SupplierController;
import com.mycompany.tpsms.database.models.Project;
import com.mycompany.tpsms.database.models.StockMovement;
import com.mycompany.tpsms.database.models.Supplier;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author blackheart
 */
public class AnalyticsPanel extends JPanel {
    private JComboBox<String> reportType;
    private JButton btnGenerate;
    private JTextArea reportArea;

    public AnalyticsPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(245, 245, 245));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header Panel
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(30, 136, 229), 
                    getWidth(), 0, new Color(33, 150, 243));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setPreferredSize(new Dimension(0, 80));
        
        JLabel titleLabel = new JLabel("Analytics Dashboard");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Control Panel
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        controlPanel.setOpaque(false);
        
        reportType = new JComboBox<>(new String[]{
            "Stock Levels", "Project Budgets", "Supplier Performance", 
            "Component Usage", "Inventory Trends"
        });
        reportType.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        reportType.setPreferredSize(new Dimension(200, 30));
        
        btnGenerate = new JButton("Generate Report");
        btnGenerate.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGenerate.setBackground(new Color(76, 175, 80));
        btnGenerate.setForeground(Color.WHITE);
        btnGenerate.setFocusPainted(false);
        btnGenerate.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        controlPanel.add(reportType);
        controlPanel.add(btnGenerate);

        // Report Display Panel
        JPanel reportPanel = new JPanel(new BorderLayout());
        reportPanel.setBackground(Color.WHITE);
        reportPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        reportArea = new JTextArea();
        reportArea.setEditable(false);
        reportArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        reportArea.setMargin(new Insets(10, 10, 10, 10));
        
        JScrollPane scrollPane = new JScrollPane(reportArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        // Add action listener to the generate button
        btnGenerate.addActionListener(e -> generateReport());

        // Layout
        reportPanel.add(scrollPane, BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);
        add(controlPanel, BorderLayout.CENTER);
        add(reportPanel, BorderLayout.SOUTH);
    }

    // Method to generate the report
    private void generateReport() {
        String selectedReport = (String) reportType.getSelectedItem();
        StringBuilder report = new StringBuilder();

        try {
            switch (selectedReport) {
                case "Stock Levels":
                    report.append("=== Stock Levels Report ===\n");
                    report.append(generateStockLevelsReport());
                    break;
                case "Project Budgets":
                    report.append("=== Project Budgets Report ===\n");
                    report.append(generateProjectBudgetsReport());
                    break;
                case "Supplier Performance":
                    report.append("=== Supplier Performance Report ===\n");
                    report.append(generateSupplierPerformanceReport());
                    break;
                case "Component Usage":
                    report.append("=== Component Usage Report ===\n");
                    report.append(generateComponentUsageReport());
                    break;
                case "Inventory Trends":
                    report.append("=== Inventory Trends Report ===\n");
                    report.append(generateInventoryTrendsReport());
                    break;
                default:
                    report.append("No report selected.");
            }
        } catch (Exception e) {
            report.append("Error generating report: " + e.getMessage());
        }

        reportArea.setText(report.toString());
    }

    // Method to generate the stock levels report
    private String generateStockLevelsReport() throws SQLException {
        StockMovementController stockController = new StockMovementController();
        List<StockMovement> stockMovements = stockController.listStockMovements();
        StringBuilder report = new StringBuilder();

        for (StockMovement movement : stockMovements) {
            report.append("Material ID: ").append(movement.getMaterialId())
                  .append(", Quantity: ").append(movement.getQuantity())
                  .append(", Type: ").append(movement.getMovementType())
                  .append(", Date: ").append(movement.getMovementDate())
                  .append("\n");
        }

        return report.toString();
    }

    // Method to generate the project budgets report
    private String generateProjectBudgetsReport() throws SQLException {
        ProjectController projectController = new ProjectController();
        List<Project> projects = projectController.listProjects();
        StringBuilder report = new StringBuilder();

//        for (Project project : projects) {
//            report.append("Project ID: ").append(project.getId())
//                  .append(", Name: ").append(project.getName())
//                  .append(", Budget: ").append(project.getBudget())
//                  .append("\n");
//        }

        return report.toString();
    }

    // Method to generate the supplier performance report
    private String generateSupplierPerformanceReport() throws SQLException {
        SupplierController supplierController = new SupplierController();
        List<Supplier> suppliers = supplierController.listSuppliers();
        StringBuilder report = new StringBuilder();

        for (Supplier supplier : suppliers) {
            report.append("Supplier ID: ").append(supplier.getId())
                  .append(", Name: ").append(supplier.getName())
                  .append(", Contact: ").append(supplier.getContactPerson())
                  .append("\n");
        }

        return report.toString();
    }

    // Method to generate the component usage report
    private String generateComponentUsageReport() throws SQLException {
        // Implementation of component usage report generation
        return "Component usage report generation not implemented yet.";
    }

    // Method to generate the inventory trends report
    private String generateInventoryTrendsReport() throws SQLException {
        // Implementation of inventory trends report generation
        return "Inventory trends report generation not implemented yet.";
    }
}
