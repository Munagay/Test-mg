package com.mycompany.tpsms.views;

import com.mycompany.tpsms.controllers.ProjectController;
import com.mycompany.tpsms.database.models.Project;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import java.util.Date;
import java.awt.GradientPaint;
import java.awt.Graphics2D;

public class AccessoriesPanel extends JPanel {
    private JTable projectsTable;
    private JButton btnNewProject;
    private DefaultTableModel tableModel;
    private ProjectController projectController;

    public AccessoriesPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(245, 245, 245));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Initialize ProjectController
        projectController = new ProjectController();

        // Header Panel
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(30, 136, 229), 
                    getWidth(), 0, new Color(33, 150, 243));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setPreferredSize(new Dimension(0, 80));
        
        JLabel titleLabel = new JLabel("Tech Stock Management");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Search Panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        searchPanel.setOpaque(false);
        
        JTextField searchField = new JTextField(20);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        
        JButton searchButton = new JButton("Search");
        searchButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        searchButton.setBackground(new Color(76, 175, 80));
        searchButton.setForeground(Color.WHITE);
        searchButton.setFocusPainted(false);
        
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        headerPanel.add(searchPanel, BorderLayout.EAST);

        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        // Project List
        String[] columnNames = {"ID", "Name", "Location", "Start Date", "End Date", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0);
        projectsTable = new JTable(tableModel);
        projectsTable.setFillsViewportHeight(true);
        projectsTable.setRowHeight(25);
        projectsTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        projectsTable.setShowGrid(false);
        projectsTable.setIntercellSpacing(new Dimension(0, 0));
        projectsTable.setSelectionBackground(new Color(33, 150, 243, 100));
        projectsTable.setSelectionForeground(Color.BLACK);
        projectsTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        projectsTable.getTableHeader().setBackground(new Color(33, 150, 243));
        projectsTable.getTableHeader().setForeground(Color.WHITE);
        projectsTable.setRowHeight(30);

        // Action Buttons Panel
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actionPanel.setBackground(Color.WHITE);
        
        btnNewProject = new JButton("Add New Item");
        btnNewProject.setIcon(new ImageIcon("src/main/resources/icons/add.png"));
        btnNewProject.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnNewProject.setBackground(new Color(33, 150, 243));
        btnNewProject.setForeground(Color.WHITE);
        btnNewProject.setFocusPainted(false);
        btnNewProject.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Add action listener for the new project button
        btnNewProject.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showNewProjectDialog();
            }
        });

        actionPanel.add(btnNewProject);

        // Layout
        tablePanel.add(new JScrollPane(projectsTable), BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        add(actionPanel, BorderLayout.SOUTH);

        // Load projects into the table
        loadProjects();
    }

    // Method to load projects into the table
    private void loadProjects() {
        try {
            List<Project> projects = projectController.listProjects();
            updateProjectsTable(projects);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load projects: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to update the projects table
    public void updateProjectsTable(List<Project> projects) {
        tableModel.setRowCount(0); // Clear existing data
        for (Project project : projects) {
            Object[] row = {
                project.getId(),
                project.getName(),
                project.getLocation(),
                project.getStartDate(),
                project.getEndDate(),
                project.getStatus()
            };
            tableModel.addRow(row);
        }
    }

    // Method to show the new project dialog
    private void showNewProjectDialog() {
        JTextField nameField = new JTextField();
        JTextField locationField = new JTextField();
        JTextField startDateField = new JTextField();
        JTextField endDateField = new JTextField();
        JTextField statusField = new JTextField();

        Object[] fields = {
            "Name:", nameField,
            "Location:", locationField,
            "Start Date (YYYY-MM-DD):", startDateField,
            "End Date (YYYY-MM-DD):", endDateField,
            "Status:", statusField
        };

        int option = JOptionPane.showConfirmDialog(
            this,
            fields,
            "New Project",
            JOptionPane.OK_CANCEL_OPTION
        );

        if (option == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                String location = locationField.getText();
                Date startDate = java.sql.Date.valueOf(startDateField.getText());
                Date endDate = java.sql.Date.valueOf(endDateField.getText());
                String status = statusField.getText();

                projectController.addProject(name, location, startDate, endDate, status);
                loadProjects(); // Refresh the table
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Invalid input: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Getter for the new project button
    public JButton getBtnNewProject() {
        return btnNewProject;
    }
}